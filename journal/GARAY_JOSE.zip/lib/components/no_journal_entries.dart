import 'package:flutter/material.dart';
import 'package:journal/styles.dart';

final styles = Styles();
Widget noEntries = styles.centerColumn([
  Icon(Icons.book, size: 100.0),
  Text('Journal'),
]);
